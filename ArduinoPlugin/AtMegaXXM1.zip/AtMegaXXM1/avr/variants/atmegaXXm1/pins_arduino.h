#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

//	ATMEGA16M1
//	TQFP32
//                                
//                 D D D D D D D D
//                 2 2 2 2 2 2 2 1
//                 6 5 4 3 2 1 0 9
//                                
//                 P P P P P P P P               
//                 D E C D B B B C
//                 1 0 0 0 7 6 5 7
//                                
//                 3 3 3 2 2 2 2 2 
//                 2 1 0 9 8 7 6 5
//                 | | | | | | | |
//	         /-----------------\
//     D0  PD2 1-|0                |-24 PB4 D18
//     D1  PD3 2-|                 |-23 PB3 D17
//     D2  PD1 3-|                 |-22 PC6 D16
//         VCC 4-|                 |-21 AREF
//         GND 5-|                 |-20 AGND
//     D3  PC2 6-|                 |-19 AVCC
//     D4  PC3 7-|                 |-18 PC5 D15
//     D5  PB0 8-|                 |-17 PC4 D14
//               \-----------------/
//                 | | | | | | | |
//                 9 1 1 1 1 1 1 1 
//                   0 1 2 3 4 5 6
//                                
//                 P P P P P P P P               
//                 B E E D D D D B      
//                 1 1 2 4 5 6 7 8       
//                                
//                 D D D D D D D D               
//                 6 7 8 9 1 1 1 1 
//                         0 1 2 3 
//



#define NUM_DIGITAL_PINS            27
#define NUM_ANALOG_INPUTS           10
#define analogInputToDigitalPin(p)  ((p < NUM_ANALOG_INPUTS) ? (p) + 24 : -1)
//#define digitalPinHasPWM(p)         ((p) == 3 || (p) == 12 || (p) == 13 || (p) == 15)
#define digitalPinHasPWM(p)        false 


static const uint8_t SS   = 1;
static const uint8_t MOSI = 6;
static const uint8_t MISO = 5;
static const uint8_t SCK  = 22;

static const uint8_t A0  = 11;
static const uint8_t A1  = 12;
static const uint8_t A2  = 13;
static const uint8_t A3  = 14;
static const uint8_t A4  = 28;
static const uint8_t A5  = 16;
static const uint8_t A6  = 26;
static const uint8_t A7  = 27;                                
static const uint8_t A8  = 17;
static const uint8_t A9  = 18;
static const uint8_t A10 = 22;


//#define digitalPinToPCICR(p)    (((p) >= 0 && (p) < NUM_DIGITAL_PINS) ? (&PCICR) : ((uint8_t *)0))
//#define digitalPinToPCICRbit(p) (((p) <= 7) ? 1 : (((p) <= 15) ? 3 : (((p) <= 23) ? 2 : 0)))
//#define digitalPinToPCMSK(p)    (((p) <= 7) ? (&PCMSK2) : (((p) <= 13) ? (&PCMSK0) : (((p) <= 21) ? (&PCMSK1) : ((uint8_t *)0))))
//#define digitalPinToPCMSKbit(p) ((p) % 8)
#define digitalPinToInterrupt(p) 	((p) == 10 ? 0 : ((p) == 11 ? 1 : ((p) == 2 ? 2 : NOT_AN_INTERRUPT)))

#ifdef ARDUINO_MAIN

const uint16_t PROGMEM port_to_mode_PGM[] =
{
  NOT_A_PORT,
  NOT_A_PORT,
  (uint16_t) &DDRB,
  (uint16_t) &DDRC,
  (uint16_t) &DDRD,
  (uint16_t) &DDRE,
};

const uint16_t PROGMEM port_to_output_PGM[] =
{
  NOT_A_PORT,
  NOT_A_PORT,
  (uint16_t) &PORTB,
  (uint16_t) &PORTC,
  (uint16_t) &PORTD,
  (uint16_t) &PORTE,
};

const uint16_t PROGMEM port_to_input_PGM[] =
{
  NOT_A_PORT,
  NOT_A_PORT,
  (uint16_t) &PINB,
  (uint16_t) &PINC,
  (uint16_t) &PIND,
  (uint16_t) &PINE,
};

#define ENTRY(Dx,Px,Nr,Timer) Px
const uint8_t PROGMEM digital_pin_to_port_PGM[32] = {
	ENTRY(D0 ,PD,2,TIMER1A),
	ENTRY(D1 ,PD,3,TIMER0A),
	ENTRY(D2 ,PD,1,TIMER1B),
	ENTRY(D3 ,PC,2,NOT_ON_TIMER),
	ENTRY(D4 ,PC,3,NOT_ON_TIMER),
	ENTRY(D5 ,PB,0,NOT_ON_TIMER),
	
	ENTRY(D6 ,PB,1,NOT_ON_TIMER),
	ENTRY(D7 ,PE,1,TIMER0B),
	ENTRY(D8 ,PE,2,NOT_ON_TIMER),
	ENTRY(D9 ,PD,4,NOT_ON_TIMER),
	ENTRY(D10,PD,5,NOT_ON_TIMER),
	ENTRY(D11,PD,6,NOT_ON_TIMER),
	ENTRY(D12,PD,7,NOT_ON_TIMER),
	ENTRY(D13,PB,8,NOT_ON_TIMER),

	ENTRY(D14,PC,4,NOT_ON_TIMER),
	ENTRY(D15,PC,5,NOT_ON_TIMER),
	ENTRY(D16,PC,6,NOT_ON_TIMER),
	ENTRY(D17,PB,3,NOT_ON_TIMER),
	ENTRY(D18,PB,4,NOT_ON_TIMER),

	ENTRY(D19,PC,7,NOT_ON_TIMER),
	ENTRY(D20,PB,5,NOT_ON_TIMER),
	ENTRY(D21,PB,6,NOT_ON_TIMER),
	ENTRY(D22,PB,7,NOT_ON_TIMER),
	ENTRY(D23,PD,0,NOT_ON_TIMER),
	ENTRY(D24,PC,0,NOT_ON_TIMER),
	ENTRY(D25,PE,0,NOT_ON_TIMER),
	ENTRY(D26,PD,1,NOT_ON_TIMER)
};
#undef ENTRY
#define ENTRY(Dx,Px,Nr,Timer) _BV(Nr)
const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[32] = {	
	ENTRY(D0 ,PD,2,TIMER1A),
	ENTRY(D1 ,PD,3,TIMER0A),
	ENTRY(D2 ,PD,1,TIMER1B),
	ENTRY(D3 ,PC,2,NOT_ON_TIMER),
	ENTRY(D4 ,PC,3,NOT_ON_TIMER),
	ENTRY(D5 ,PB,0,NOT_ON_TIMER),
	
	ENTRY(D6 ,PB,1,NOT_ON_TIMER),
	ENTRY(D7 ,PE,1,TIMER0B),
	ENTRY(D8 ,PE,2,NOT_ON_TIMER),
	ENTRY(D9 ,PD,4,NOT_ON_TIMER),
	ENTRY(D10,PD,5,NOT_ON_TIMER),
	ENTRY(D11,PD,6,NOT_ON_TIMER),
	ENTRY(D12,PD,7,NOT_ON_TIMER),
	ENTRY(D13,PB,8,NOT_ON_TIMER),

	ENTRY(D14,PC,4,NOT_ON_TIMER),
	ENTRY(D15,PC,5,NOT_ON_TIMER),
	ENTRY(D16,PC,6,NOT_ON_TIMER),
	ENTRY(D17,PB,3,NOT_ON_TIMER),
	ENTRY(D18,PB,4,NOT_ON_TIMER),

	ENTRY(D19,PC,7,NOT_ON_TIMER),
	ENTRY(D20,PB,5,NOT_ON_TIMER),
	ENTRY(D21,PB,6,NOT_ON_TIMER),
	ENTRY(D22,PB,7,NOT_ON_TIMER),
	ENTRY(D23,PD,0,NOT_ON_TIMER),
	ENTRY(D24,PC,0,NOT_ON_TIMER),
	ENTRY(D25,PE,0,NOT_ON_TIMER),
	ENTRY(D26,PD,1,NOT_ON_TIMER)
};
#undef ENTRY
#define ENTRY(Dx,Px,Nr,Timer) Timer
const uint8_t PROGMEM digital_pin_to_timer_PGM[] =
{
	ENTRY(D0 ,PD,2,TIMER1A),
	ENTRY(D1 ,PD,3,TIMER0A),
	ENTRY(D2 ,PD,1,TIMER1B),
	ENTRY(D3 ,PC,2,NOT_ON_TIMER),
	ENTRY(D4 ,PC,3,NOT_ON_TIMER),
	ENTRY(D5 ,PB,0,NOT_ON_TIMER),
	
	ENTRY(D6 ,PB,1,NOT_ON_TIMER),
	ENTRY(D7 ,PE,1,TIMER0B),
	ENTRY(D8 ,PE,2,NOT_ON_TIMER),
	ENTRY(D9 ,PD,4,NOT_ON_TIMER),
	ENTRY(D10,PD,5,NOT_ON_TIMER),
	ENTRY(D11,PD,6,NOT_ON_TIMER),
	ENTRY(D12,PD,7,NOT_ON_TIMER),
	ENTRY(D13,PB,8,NOT_ON_TIMER),

	ENTRY(D14,PC,4,NOT_ON_TIMER),
	ENTRY(D15,PC,5,NOT_ON_TIMER),
	ENTRY(D16,PC,6,NOT_ON_TIMER),
	ENTRY(D17,PB,3,NOT_ON_TIMER),
	ENTRY(D18,PB,4,NOT_ON_TIMER),

	ENTRY(D19,PC,7,NOT_ON_TIMER),
	ENTRY(D20,PB,5,NOT_ON_TIMER),
	ENTRY(D21,PB,6,NOT_ON_TIMER),
	ENTRY(D22,PB,7,NOT_ON_TIMER),
	ENTRY(D23,PD,0,NOT_ON_TIMER),
	ENTRY(D24,PC,0,NOT_ON_TIMER),
	ENTRY(D25,PE,0,NOT_ON_TIMER),
	ENTRY(D26,PD,1,NOT_ON_TIMER)
};
#undef ENTRY

#endif
// These serial port names are intended to allow libraries and architecture-neutral
// sketches to automatically default to the correct port name for a particular type
// of use.  For example, a GPS module would normally connect to SERIAL_PORT_HARDWARE_OPEN,
// the first hardware serial port whose RX/TX pins are not dedicated to another use.
//
// SERIAL_PORT_MONITOR        Port which normally prints to the Arduino Serial Monitor
//
// SERIAL_PORT_USBVIRTUAL     Port which is USB virtual serial
//
// SERIAL_PORT_LINUXBRIDGE    Port which connects to a Linux system via Bridge library
//
// SERIAL_PORT_HARDWARE       Hardware serial port, physical RX & TX pins.
//
// SERIAL_PORT_HARDWARE_OPEN  Hardware serial ports which are open for use.  Their RX & TX
//                            pins are NOT connected to anything by default.
#define SERIAL_PORT_MONITOR   Serial
#define SERIAL_PORT_HARDWARE  Serial

#endif
